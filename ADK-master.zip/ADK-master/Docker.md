# Docker Course Content

### Day-1. Docker Engine

    1.1. Dokcer Introduction.
    1.2. Dokcer Installtion.
    1.3. Writing simple Dockerfile.
    1.4. Creating images.
    1.5. Creating containers.
    1.6. Docker Volumes.
    1.7. Docker Hub.
    
### Day-2. Docker Compose

    2.1. docker-compose installation.
    2.2. Writing docker-compose.yml file.
    2.3. docker-compose examples.
    
### Day-3. Jenkins with Docker

    3.1. A simple example on Jenkins with Docker.
    
### Day-4. Dokcer Machine

    4.1. docker-machine installtion.
    4.2. Creating docker hosts on AWS using docker-machine.
    
### Day-5. Dokcer Swam

    5.1. docker swam mode.
    5.2. swam init.
    5.3. manager & worker concept.
    5.4. Deploying apps to docker swam.
    5.5. commands in swam.
    
### Day-6. Other concepts on Docker & Interview Questions
