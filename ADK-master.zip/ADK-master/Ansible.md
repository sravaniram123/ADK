# Ansible Course

### Day-1. 
                1.1. Ansible introduction.
                1.2. Ansible installation.
                1.3. Ansible archetucture.
                1.4. Connection between Nodes.
                
### Day-2. 

                2.1. Writing Inventory file.
                2.2. Ansible Ad-hoc commands.
                2.3. Writing playbooks.
                
### Day-3. 

                3.1. Ad-hoc Commands with modules like ping,User,copy etc.
                3.2. Roles.
                3.2. Provisioning Servers(using playbooks, roles).
                
### Day-4. 

                4.1. Configure CI/CD pipleine with Jenkins + Nexus + Ansible.
                4.2. Deployment using Ansible.
                
### Day-5. Other Concepts & Interview Questions.
