# Kubernetes Course: Kubernetes + Docker + AWS 

### Day-1. Kubernetes Introduction & Archetecture.

          1.1. Kubernetes setup.
          1.2. Master.
          1.3. Nodes.
          1.4. Pods.
          1.5. Cluster.

### Day-2. Creating cluster using kubeadm (AWS & Docker).
        
          2.1. Single host network.
          2.2. Multi host network.

### Day-3. Kubectl

          3.1. Kubectl Commands.
          
### Day-4. Deploying apps on Kubernetes cluster.

### Day-5. Other concepts & Interview Questions.
